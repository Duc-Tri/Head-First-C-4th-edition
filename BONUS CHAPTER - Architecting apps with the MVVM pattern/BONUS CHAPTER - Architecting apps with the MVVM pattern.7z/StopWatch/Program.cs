﻿using Stopwatch.View;

Console.WriteLine("MVVM STOPWATCH =========================");

StopwatchView stopwatchView = new StopwatchView();